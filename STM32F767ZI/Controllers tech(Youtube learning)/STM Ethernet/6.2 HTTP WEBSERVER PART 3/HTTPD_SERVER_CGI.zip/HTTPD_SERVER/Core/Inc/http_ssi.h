/*
 * http_ssi.h
 *
 *  Created on: 11-Oct-2021
 *      Author: controllerstech
 */

#ifndef INC_HTTP_SSI_H_
#define INC_HTTP_SSI_H_

void http_server_init (void);


#endif /* INC_HTTP_SSI_H_ */
